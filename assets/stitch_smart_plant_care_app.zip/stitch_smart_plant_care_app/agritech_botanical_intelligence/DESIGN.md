---
name: AgriTech Botanical Intelligence
colors:
  surface: '#f2fcf2'
  surface-dim: '#d2ddd3'
  surface-bright: '#f2fcf2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ecf6ec'
  surface-container: '#e6f1e7'
  surface-container-high: '#e1ebe1'
  surface-container-highest: '#dbe5db'
  on-surface: '#151e18'
  on-surface-variant: '#404942'
  inverse-surface: '#29332c'
  inverse-on-surface: '#e9f3ea'
  outline: '#707971'
  outline-variant: '#bfc9c0'
  surface-tint: '#226b47'
  primary: '#004328'
  on-primary: '#ffffff'
  primary-container: '#0d5c3a'
  on-primary-container: '#8ad2a7'
  inverse-primary: '#8ed6aa'
  secondary: '#006d40'
  on-secondary: '#ffffff'
  secondary-container: '#7afbb1'
  on-secondary-container: '#007444'
  tertiary: '#6a2100'
  on-tertiary: '#ffffff'
  tertiary-container: '#903002'
  on-tertiary-container: '#ffb093'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a9f3c5'
  primary-fixed-dim: '#8ed6aa'
  on-primary-fixed: '#002111'
  on-primary-fixed-variant: '#005232'
  secondary-fixed: '#7afbb1'
  secondary-fixed-dim: '#5cde97'
  on-secondary-fixed: '#002110'
  on-secondary-fixed-variant: '#00522f'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#812900'
  background: '#f2fcf2'
  on-background: '#151e18'
  surface-variant: '#dbe5db'
typography:
  display-lg:
    fontFamily: IBM Plex Sans
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-sm:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-metric:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style
The design system channels an agronomic intelligence aesthetic: a high-precision fusion of field biology, satellite telemetry, and computer vision. It departs from cliché rustic agriculture in favor of an authoritative, clean "green tech" precision interface engineered for outdoor daylight readability and swift diagnostic triage. 

Visual tone balances scientific rigor with organic vitality. Interfaces must feel crisp, tactile, and calm—reducing cognitive load for agronomists, field operators, and precision farmers scanning plant health metrics under intense natural sunlight. Micro-interactions should be swift and decisive, utilizing subtle haptic-inspired feedback cues and organic easing.

## Colors
The palette balances dense chlorophyllic depth with vibrant diagnostic signals:

- **Primary (`#0D5C3A` - Deep Emerald):** Represents foundational agronomic stability, deep plant matter, and institutional reliability. Applied to top app bars, primary interactive buttons, and high-level navigational anchors.
- **Secondary (`#2BB673` - Vibrant Leaf Green):** Represents active photosynthesizing tissue, vitality, and AI diagnostic verification. Used for success states, optimal health indicators, and high-priority action confirmations.
- **Accent Mint (`#D8F3DC` surface, `#107C41` text):** Applied to active navigation indicators, selected pill filters, and soft telemetry card backgrounds.
- **Neutral Core (`#1B241E` - Forest Obsidian):** Ultra-deep chlorophyll neutral replacing generic grays with a subtle organic undertone. Prevents eye fatigue outdoors while preserving crisp contrast.
- **Canvas (`#F7FAF8`):** Off-white tinted with faint sage to eliminate harsh solar glare on mobile screens.
- **Diagnostic Tiers:**
  - *Healthy (Nominal):* `#2BB673` text / `#E8F8F0` fill
  - *Moderate (Warning Amber):* `#E59819` text / `#FEF6E9` fill
  - *Severe (Pathogen / Pest Crimson):* `#D9383A` text / `#FDF2F2` fill

## Typography
IBM Plex Sans provides the exact engineering precision needed for a bio-technical tool. In multilingual deployment with Arabic, paired directly with IBM Plex Sans Arabic to retain identical metric scales, stroke contrast, and structural baseline behavior.

- Numerical plant telemetry, soil moisture percentages, and spectral indexes rely on tabular figures (`tnum`) to eliminate jitter during real-time sensor refreshes.
- Hierarchy emphasizes scannability: bold diagnostic titles pair with high-legibility body tokens configured for rapid field assessments.
- Right-to-Left (RTL) mirroring maintains optical stroke balance and proportional baseline height automatically across Arabic script instances.

## Layout & Spacing
A native mobile-first fluid layout configured to support 360px to 428px standard viewport widths, scaling to tablet inspection dashboards smoothly:

- **Mobile Viewport Grid:** 4-column fluid layout with `16px` (`1rem`) outer margins and `16px` gutters.
- **Touch Target Density:** All interactive touch footprints respect an absolute minimum boundary of `48x48px` to facilitate single-handed thumb scanning in dirty or gloved field conditions.
- **Vertical Spacing Rhythm:** Strictly uses an 8pt base grid with a 4pt sub-grid for badge padding and tabular alignment.
- **Bottom Safe Area:** Bottom nav bars and primary Floating Action Buttons (FABs) integrate dynamic safe-area insets (`env(safe-area-inset-bottom) + 12px`) ensuring frictionless edge interaction on edge-to-edge mobile devices.

## Elevation & Depth
Depth is constructed through subtle vegetal tonal layering rather than aggressive pitch-black shadows:

- **Level 0 (Field Canvas):** `#F7FAF8` flat surface.
- **Level 1 (Card & Module Layer):** Pure white `#FFFFFF` surface elevated with an ambient leaf-tinted shadow: `0px 2px 8px rgba(13, 92, 58, 0.05)`, bounded by a hair-line border: `1px solid rgba(13, 92, 58, 0.08)`.
- **Level 2 (Diagnostic Floating Modals & Sheets):** `#FFFFFF` with `0px 8px 24px rgba(13, 92, 58, 0.12)`, delivering defined depth without muddying saturated colors.
- **Level 3 (AI Scan HUD Overlays):** Semi-translucent glass layer with `backdrop-filter: blur(16px)` and background `rgba(27, 36, 30, 0.72)` with white hairline borders for in-camera diagnostics.

## Shapes
Geometry mirrors natural leaf contours reconciled with modern industrial UI:

- **Base Cards & Sheets:** `16px` (`rounded-lg`) corner radii create a warm, organic feel while remaining structurally rigid for structured data tables.
- **Inner Metric Cells:** `12px` (`rounded-md`) to ensure nested geometric harmony inside parent cards.
- **Status Badges & Pill Chips:** Full pill radii (`9999px`) provide distinct, unmistakable visual separation from square data cards.
- **Input Fields & Search Bars:** `12px` rounded boundaries provide touch-friendly visual affordance.

## Components

### Plant Health Severity Badges
Pill-shaped badges (`height: 28px`, `padding: 0 12px`, `border-radius: 9999px`) featuring high-contrast indicator dots and crisp typography (`label-sm`):
- **Healthy:** `#E8F8F0` fill, `#0D5C3A` text, leading `6px` pulsating dot `#2BB673`.
- **Moderate:** `#FEF6E9` fill, `#9A6200` text, leading `6px` solid dot `#E59819`.
- **Severe:** `#FDF2F2` fill, `#B91C1C` text, leading `6px` warning dot `#D9383A`.

### Diagnostic AI Cards
Engineered white card surfaces with `16px` radius and `16px` internal padding. Split layout featuring:
1. Top row: Crop taxonomic name alongside real-time severity badge.
2. Middle row: Two-column sensor readouts (Chlorophyll Index, Soil Hydration) styled using `data-metric` typography.
3. Bottom row: Quick action links ("View Pathology", "Prescribe Treatment") punctuated with directional micro-icons.

### Primary & Action Buttons
- **Primary:** Full width or pinned bottom action bar. Deep Emerald fill (`#0D5C3A`), white text, `48px` minimum height, `12px` corner radius. Active state transitions to `#083B25`.
- **Secondary / Ghost:** `#E8F8F0` mint background with `#0D5C3A` label.
- **AI Scan Trigger:** Centered elevated round floating button (`56x56px`) with emerald-to-leaf-green gradient (`#0D5C3A` to `#2BB673`) housing a high-precision camera viewfinder icon.

### Form Inputs & Selectors
- Flat `#FFFFFF` fields framed with `1px solid rgba(13, 92, 58, 0.15)`.
- Active focus state swaps to `2px solid #2BB673` with a soft mint focus ring (`0px 0px 0px 3px rgba(43, 182, 115, 0.2)`).
- Input labels use `label-md` seated above the input frame for outdoor legibility.

### Bottom Navigation Bar
- Fixed frosted bottom bar (`height: 64px + safe-area`) using `rgba(255, 255, 255, 0.92)` with `backdrop-filter: blur(12px)` and top divider `1px solid rgba(13, 92, 58, 0.08)`.
- Five-node distribution: Field Monitor, Crop Catalog, AI Scan (Elevated center hub), Diagnostic Records, and Profile.
- Selected state activates `#0D5C3A` icon tint with an organic mint indicator pill behind the active item.